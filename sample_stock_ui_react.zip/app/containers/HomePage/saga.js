import { takeLatest, call, put, select } from 'redux-saga/effects';
import { requestGet } from '../../utils/request';
import { STOCK, STOCKACTION } from './constants';

export function* stockInfo(data) {
  try {
    console.log('here at saga');
    const repos = yield call(requestGet);
    console.log(repos);
    yield put({ type: STOCK, payload: repos });

  } catch (err) {
    // errorMsg(err);
  }
}
// Individual exports for testing
export default function* homePageSaga() {
  // See example in containers/HomePage/saga.js
  yield takeLatest(STOCKACTION, stockInfo);
}
