/*
 *
 * HomePage actions
 *
 */

import { STOCKACTION } from './constants';

export function stockAction() {
  return {
    type: STOCKACTION,
  };
}
