/**
 *
 * HomePage
 *
 */

import React, { memo, useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { Row, Col } from 'antd';
import { useInjectSaga } from 'utils/injectSaga';
import { useInjectReducer } from 'utils/injectReducer';
import makeSelectHomePage from './selectors';
import reducer from './reducer';
import saga from './saga';
import messages from './messages';
import { stockAction } from './actions';
import DragableDataTable from '../../components/DragableDataTable';
import GraphicalData from '../../components/GraphicalData';

export function HomePage(props) {
  useInjectReducer({ key: 'homePage', reducer });
  useInjectSaga({ key: 'homePage', saga });

  console.log('component did mount', props);
  const StockData = props.homePage.TRADE;
  console.log(StockData);
  useEffect(() => {
    props.stockActionLoad();
  }, []);

  return (
    <div className="report">
      {/* <Helmet>
        <title>HomePage</title>
        <meta name="description" content="Description of HomePage" />
      </Helmet>
      <FormattedMessage {...messages.header} /> */}
      <Row>
        <Col span={20}>
          {StockData ? <DragableDataTable dataSource={StockData} /> : null}
        </Col>
        <Col span={4}>
          {StockData ? <GraphicalData salesPieData={StockData} /> : null}
        </Col>
      </Row>
    </div>
  );
}

// HomePage.propTypes = {
//   dispatch: PropTypes.func.isRequired,
// };

const mapStateToProps = createStructuredSelector({
  homePage: makeSelectHomePage(),
});

function mapDispatchToProps(dispatch) {
  return {
    stockActionLoad: () => dispatch(stockAction()),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(
  withConnect,
  memo,
)(HomePage);
