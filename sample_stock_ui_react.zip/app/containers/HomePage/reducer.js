/*
 *
 * HomePage reducer
 *
 */
import produce from 'immer';
import { STOCK } from './constants';

export const initialState = {
  TRADE: null,
};

/* eslint-disable default-case, no-param-reassign */
const homePageReducer = (state = initialState, action) =>
  produce(state, (/* draft */) => {
    switch (action.type) {
      case STOCK:
        return {
          ...state,
          TRADE: action.payload,
        };
    }
  });

export default homePageReducer;
