/*
 *
 * HomePage constants
 *
 */

export const STOCK = 'STOCK';
export const STOCKACTION = 'STOCKACTION';
// export const DEFAULT_ACTION = 'app/HomePage/DEFAULT_ACTION';
