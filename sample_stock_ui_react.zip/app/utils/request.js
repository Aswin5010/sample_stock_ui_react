const axios = require('axios');
const basePath = require('./data.json');

export function requestGet() {
  /* return axios
    .get(`${basePath}`)
    .then(response => response.data)
    .catch(error => error.response.data)
    .finally(() => {
      // always execute
    }); */
  return basePath;
}
