/**
 *
 * GraphicalData
 *
 */

import React, { memo } from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

import { FormattedMessage } from 'react-intl';
import { Pie, yuan } from 'ant-design-pro/lib/Charts';
// import messages from './messages';

function GraphicalData({ salesPieData }) {
  const chartData = salesPieData.map(data => ({
    x: data.basis,
    y: data.invested_amount,
  }));
  return (
    <div>
      <span style={{ fontSize: '50px' }}> Portfolio </span>
      <Pie
        className="chartView"
        hasLegend
        title="graphicsl view"
        data={chartData}
        valueFormat={val => (
          <span dangerouslySetInnerHTML={{ __html: yuan(val) }} />
        )}
        height={294}
      />
    </div>
  );
}

// GraphicalData.propTypes = {};

export default memo(GraphicalData);
