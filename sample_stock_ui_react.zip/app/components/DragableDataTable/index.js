/**
 *
 * DragableDataTable
 *
 */

import React, { Fragment, memo, useState } from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

// import { FormattedMessage } from 'react-intl';

import { Table, List, Avatar, Progress, Slider, Button } from 'antd';
import {
  sortableContainer,
  sortableElement,
  sortableHandle,
} from 'react-sortable-hoc';
import { MenuOutlined } from '@ant-design/icons';
import arrayMove from 'array-move';
import './style.css';
// import messages from './messages';

const DragHandle = sortableHandle(() => (
  <MenuOutlined style={{ cursor: 'grab', color: '#999' }} />
));

const Price = data => (
  <span className="dollar">
    $<span className="price">{data.data.price}</span>
  </span>
);

const Script = data => (
  <>
    <span className="sriptName">{data.data.name}</span>
    <br />
    <span className="sriptDescription">{data.data.description}</span>
  </>
);

const QuoteInfo = data => (
  <List
    className="demo-loadmore-list"
    itemLayout="horizontal"
    dataSource={[data]}
    renderItem={item => (
      <div>
        <List.Item>
          <List.Item.Meta
            avatar={
              <Avatar src="https://img.icons8.com/small/32/000000/estimates.png" />
            }
            title="quantity"
          />
          <div>{item.data.quantity}</div>
        </List.Item>
        <List.Item>
          <List.Item.Meta avatar="@" title="Avg. Cost" />
          <div>{item.data.average_cost}</div>
        </List.Item>
        <List.Item>
          <List.Item.Meta
            avatar={
              <Avatar src="https://img.icons8.com/ios-filled/80/000000/investment.png" />
            }
            title="Invested Amt"
          />
          <div>{item.data.invested_amount}</div>
        </List.Item>
      </div>
    )}
  />
);

const MarketValue = data => (
  <List
    className="demo-loadmore-list"
    itemLayout="horizontal"
    dataSource={[data]}
    renderItem={item => (
      <div>
        <List.Item>
          <List.Item.Meta title="Market Value" />
          <div>${item.data.invested_amount}</div>
        </List.Item>
        <List.Item>
          <List.Item.Meta description="% of portfolio value" />
          <div>${item.data.portfolio_value}</div>
        </List.Item>
        <Progress
          type="line"
          percent={item.data.portfolio_value}
          status="success"
          showInfo={false}
        />
      </div>
    )}
  />
);

const Unrealized = data => (
  <List
    className="demo-loadmore-list"
    itemLayout="horizontal"
    dataSource={[data]}
    renderItem={item => (
      <div>
        <List.Item>
          <List.Item.Meta title="Unrealized P/L" />
          <div>${item.data.unrealized_pl}</div>
        </List.Item>
        <List.Item>
          <List.Item.Meta description="% returns" />
          <div>${item.data.returns}</div>
        </List.Item>
        <Slider
          range
          defaultValue={[50 - item.data.returns, 50 + item.data.returns]}
          disabled={false}
        />
      </div>
    )}
  />
);

const ButtonBuy = data => (
  <List
    className="demo-loadmore-list"
    itemLayout="horizontal"
    dataSource={[data]}
    renderItem={() => (
      <div>
        <List.Item>
          <Button danger> BUY </Button>
        </List.Item>
        <List.Item>
          <Button danger> SELL </Button>
        </List.Item>
      </div>
    )}
  />
);

const columns = [
  {
    // title: 'Sort',
    dataIndex: 'sort',
    width: 30,
    className: 'drag-visible',
    render: () => <DragHandle />,
  },
  {
    // title: 'Price',
    dataIndex: 'price',
    render: (data, fullData) => <Price data={fullData} />,
  },
  {
    // title: 'script',
    dataIndex: 'script',
    render: (data, fullData) => <Script data={fullData} />,
  },
  {
    // title: 'Quantity',
    dataIndex: 'quantity',
    render: (data, fullData) => <QuoteInfo data={fullData} />,
  },
  {
    // title: 'Average_Cost',
    dataIndex: 'average_cost',
    render: (data, fullData) => <MarketValue data={fullData} />,
  },
  {
    // title: 'Average_Cost',
    dataIndex: 'average_cost',
    render: (data, fullData) => <Unrealized data={fullData} />,
  },
  {
    // title: 'Average_Cost',
    dataIndex: 'average_cost',
    render: (data, fullData) => <ButtonBuy data={fullData} />,
  },
];

// const dataSource = [
//   {
//     script: 'aadr',
//     quantity: 430,
//     price: '50.30',
//     average_cost: 41.75,
//     invested_amount: 17952.07,
//     portfolio_value: 22.06,
//     unrealized_pl: 3676.93,
//     returns: 20.48,
//   },
//   {
//     script: 'aadr',
//     quantity: 430,
//     price: '50.30',
//     average_cost: 41.75,
//     invested_amount: 17952.07,
//     portfolio_value: 22.06,
//     unrealized_pl: 3676.93,
//     returns: 20.48,
//   },
//   {
//     script: 'aadr',
//     quantity: 430,
//     price: '50.30',
//     average_cost: 41.75,
//     invested_amount: 17952.07,
//     portfolio_value: 22.06,
//     unrealized_pl: 3676.93,
//     returns: 20.48,
//   },
//   {
//     script: 'aadr',
//     quantity: 430,
//     price: '50.30',
//     average_cost: 41.75,
//     invested_amount: 17952.07,
//     portfolio_value: 22.06,
//     unrealized_pl: 3676.93,
//     returns: 20.48,
//   },
// ];

const SortableItem = sortableElement(props => <tr {...props} />);
const SortableContainer = sortableContainer(props => <tbody {...props} />);

function DragableDataTable({ dataSource }) {
  // const dataSource = {
  //   dataSource: data,
  // };

  const onSortEnd = ({ oldIndex, newIndex }) => {
    // const { dataSource } = this.state;
    if (oldIndex !== newIndex) {
      const newData = arrayMove(
        [].concat(dataSource),
        oldIndex,
        newIndex,
      ).filter(el => !!el);
      console.log('Sorted items: ', newData);
      // this.setState({ dataSource: newData });
      // useState
    }
  };

  const DraggableContainer = props => (
    <SortableContainer
      useDragHandle
      disableAutoscroll
      helperClass="row-dragging"
      onSortEnd={onSortEnd}
      {...props}
    />
  );

  const DraggableBodyRow = ({ className, style, ...restProps }) => {
    // const { dataSource } = this.state;
    // function findIndex base on Table rowKey props and should always be a right array index
    const index = dataSource.findIndex(x => x.id === restProps['data-row-key']);
    return <SortableItem index={index} {...restProps} />;
  };

  // const { dataSource } = this.state;
  return (
    <Table
      className="tableView"
      pagination={false}
      dataSource={dataSource}
      columns={columns}
      rowKey="id"
      components={{
        body: {
          wrapper: DraggableContainer,
          row: DraggableBodyRow,
        },
      }}
    />
  );
}

DragableDataTable.propTypes = {};

export default memo(DragableDataTable);
