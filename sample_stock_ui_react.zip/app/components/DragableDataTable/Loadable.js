/**
 *
 * Asynchronously loads the component for DragableDataTable
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
